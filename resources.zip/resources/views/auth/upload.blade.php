@extends('layouts.app')

@section('content')
<div class="container-fluid upload d-flex justify-content-center align-items-center">
            <div class="upload-photo d-flex align-items-center justify-content-center">
                <div class="upload-photo-inner text-center">
                    <img src="https://res.cloudinary.com/aarav/image/upload/v1547018059/avatar-male-silhouette-hi_t71mxg.png" class="upload-image">
                    <hr>
                    <h3>Upload Photo</h3>
                    <p>from the computer</p>
                    <button class="btn">Upload</button>
                </div>
            </div>
        </div>
@endsections